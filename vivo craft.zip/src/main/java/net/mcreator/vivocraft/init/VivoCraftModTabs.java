
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.vivocraft.init;

import net.minecraftforge.api.distmarker.OnlyIn;
import net.minecraftforge.api.distmarker.Dist;

import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.CreativeModeTab;

public class VivoCraftModTabs {
	public static CreativeModeTab TAB_VIVOCRAFT;
	public static CreativeModeTab TAB_NARZEDZIA;
	public static CreativeModeTab TAB_ZBROJE;

	public static void load() {
		TAB_VIVOCRAFT = new CreativeModeTab("tabvivocraft") {
			@Override
			public ItemStack makeIcon() {
				return new ItemStack(VivoCraftModItems.APERYTOWASZTABKAPACK_SWORD.get());
			}

			@OnlyIn(Dist.CLIENT)
			public boolean hasSearchBar() {
				return false;
			}
		};
		TAB_NARZEDZIA = new CreativeModeTab("tabnarzedzia") {
			@Override
			public ItemStack makeIcon() {
				return new ItemStack(VivoCraftModItems.NVIDIORTOWY_ARMOR_CHESTPLATE.get());
			}

			@OnlyIn(Dist.CLIENT)
			public boolean hasSearchBar() {
				return false;
			}
		};
		TAB_ZBROJE = new CreativeModeTab("tabzbroje") {
			@Override
			public ItemStack makeIcon() {
				return new ItemStack(VivoCraftModItems.APERYTOWA_ZBROJA_ARMOR_LEGGINGS.get());
			}

			@OnlyIn(Dist.CLIENT)
			public boolean hasSearchBar() {
				return false;
			}
		};
	}
}
