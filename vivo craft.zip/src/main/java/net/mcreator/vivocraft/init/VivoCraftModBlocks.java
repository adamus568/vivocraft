
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.vivocraft.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.level.block.Block;

import net.mcreator.vivocraft.block.NvidiorytBlock;
import net.mcreator.vivocraft.block.KomputerBlock;
import net.mcreator.vivocraft.block.AperytBlock;
import net.mcreator.vivocraft.VivoCraftMod;

public class VivoCraftModBlocks {
	public static final DeferredRegister<Block> REGISTRY = DeferredRegister.create(ForgeRegistries.BLOCKS, VivoCraftMod.MODID);
	public static final RegistryObject<Block> APERYT = REGISTRY.register("aperyt", () -> new AperytBlock());
	public static final RegistryObject<Block> NVIDIORYT = REGISTRY.register("nvidioryt", () -> new NvidiorytBlock());
	public static final RegistryObject<Block> KOMPUTER = REGISTRY.register("komputer", () -> new KomputerBlock());
}
