
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.vivocraft.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.BlockItem;

import net.mcreator.vivocraft.item.ZasilacItem;
import net.mcreator.vivocraft.item.WentylatorItem;
import net.mcreator.vivocraft.item.SztabkanvidiorytuItem;
import net.mcreator.vivocraft.item.ProcesorItem;
import net.mcreator.vivocraft.item.PlytkadrukowanaItem;
import net.mcreator.vivocraft.item.PlytaglownaItem;
import net.mcreator.vivocraft.item.PlastikItem;
import net.mcreator.vivocraft.item.ObudowaItem;
import net.mcreator.vivocraft.item.NvidiowySwordItem;
import net.mcreator.vivocraft.item.NvidiowyShovelItem;
import net.mcreator.vivocraft.item.NvidiowyPickaxeItem;
import net.mcreator.vivocraft.item.NvidiowyHoeItem;
import net.mcreator.vivocraft.item.NvidiowyAxeItem;
import net.mcreator.vivocraft.item.NvidiortowyArmorItem;
import net.mcreator.vivocraft.item.KfasItem;
import net.mcreator.vivocraft.item.KartagraficznaItem;
import net.mcreator.vivocraft.item.KabelekItem;
import net.mcreator.vivocraft.item.ChipkartyItem;
import net.mcreator.vivocraft.item.BongolItem;
import net.mcreator.vivocraft.item.BogolaItem;
import net.mcreator.vivocraft.item.AperytowasztabkapackSwordItem;
import net.mcreator.vivocraft.item.AperytowasztabkapackShovelItem;
import net.mcreator.vivocraft.item.AperytowasztabkapackPickaxeItem;
import net.mcreator.vivocraft.item.AperytowasztabkapackHoeItem;
import net.mcreator.vivocraft.item.AperytowasztabkapackAxeItem;
import net.mcreator.vivocraft.item.AperytowasztabkaItem;
import net.mcreator.vivocraft.item.Aperytowa_zbrojaArmorItem;
import net.mcreator.vivocraft.VivoCraftMod;

public class VivoCraftModItems {
	public static final DeferredRegister<Item> REGISTRY = DeferredRegister.create(ForgeRegistries.ITEMS, VivoCraftMod.MODID);
	public static final RegistryObject<Item> APERYT = block(VivoCraftModBlocks.APERYT, VivoCraftModTabs.TAB_VIVOCRAFT);
	public static final RegistryObject<Item> APERYTOWASZTABKA = REGISTRY.register("aperytowasztabka", () -> new AperytowasztabkaItem());
	public static final RegistryObject<Item> APERYTOWA_ZBROJA_ARMOR_HELMET = REGISTRY.register("aperytowa_zbroja_armor_helmet",
			() -> new Aperytowa_zbrojaArmorItem.Helmet());
	public static final RegistryObject<Item> APERYTOWA_ZBROJA_ARMOR_CHESTPLATE = REGISTRY.register("aperytowa_zbroja_armor_chestplate",
			() -> new Aperytowa_zbrojaArmorItem.Chestplate());
	public static final RegistryObject<Item> APERYTOWA_ZBROJA_ARMOR_LEGGINGS = REGISTRY.register("aperytowa_zbroja_armor_leggings",
			() -> new Aperytowa_zbrojaArmorItem.Leggings());
	public static final RegistryObject<Item> APERYTOWA_ZBROJA_ARMOR_BOOTS = REGISTRY.register("aperytowa_zbroja_armor_boots",
			() -> new Aperytowa_zbrojaArmorItem.Boots());
	public static final RegistryObject<Item> BOGOLA = REGISTRY.register("bogola", () -> new BogolaItem());
	public static final RegistryObject<Item> BONGOL = REGISTRY.register("bongol", () -> new BongolItem());
	public static final RegistryObject<Item> NVIDIORYT = block(VivoCraftModBlocks.NVIDIORYT, VivoCraftModTabs.TAB_VIVOCRAFT);
	public static final RegistryObject<Item> APERYTOWASZTABKAPACK_PICKAXE = REGISTRY.register("aperytowasztabkapack_pickaxe",
			() -> new AperytowasztabkapackPickaxeItem());
	public static final RegistryObject<Item> APERYTOWASZTABKAPACK_AXE = REGISTRY.register("aperytowasztabkapack_axe",
			() -> new AperytowasztabkapackAxeItem());
	public static final RegistryObject<Item> APERYTOWASZTABKAPACK_SWORD = REGISTRY.register("aperytowasztabkapack_sword",
			() -> new AperytowasztabkapackSwordItem());
	public static final RegistryObject<Item> APERYTOWASZTABKAPACK_SHOVEL = REGISTRY.register("aperytowasztabkapack_shovel",
			() -> new AperytowasztabkapackShovelItem());
	public static final RegistryObject<Item> APERYTOWASZTABKAPACK_HOE = REGISTRY.register("aperytowasztabkapack_hoe",
			() -> new AperytowasztabkapackHoeItem());
	public static final RegistryObject<Item> SZTABKANVIDIORYTU = REGISTRY.register("sztabkanvidiorytu", () -> new SztabkanvidiorytuItem());
	public static final RegistryObject<Item> NVIDIOWY_PICKAXE = REGISTRY.register("nvidiowy_pickaxe", () -> new NvidiowyPickaxeItem());
	public static final RegistryObject<Item> NVIDIOWY_AXE = REGISTRY.register("nvidiowy_axe", () -> new NvidiowyAxeItem());
	public static final RegistryObject<Item> NVIDIOWY_SWORD = REGISTRY.register("nvidiowy_sword", () -> new NvidiowySwordItem());
	public static final RegistryObject<Item> NVIDIOWY_SHOVEL = REGISTRY.register("nvidiowy_shovel", () -> new NvidiowyShovelItem());
	public static final RegistryObject<Item> NVIDIOWY_HOE = REGISTRY.register("nvidiowy_hoe", () -> new NvidiowyHoeItem());
	public static final RegistryObject<Item> KARTAGRAFICZNA = REGISTRY.register("kartagraficzna", () -> new KartagraficznaItem());
	public static final RegistryObject<Item> CHIPKARTY = REGISTRY.register("chipkarty", () -> new ChipkartyItem());
	public static final RegistryObject<Item> NVIDIORTOWY_ARMOR_HELMET = REGISTRY.register("nvidiortowy_armor_helmet",
			() -> new NvidiortowyArmorItem.Helmet());
	public static final RegistryObject<Item> NVIDIORTOWY_ARMOR_CHESTPLATE = REGISTRY.register("nvidiortowy_armor_chestplate",
			() -> new NvidiortowyArmorItem.Chestplate());
	public static final RegistryObject<Item> NVIDIORTOWY_ARMOR_LEGGINGS = REGISTRY.register("nvidiortowy_armor_leggings",
			() -> new NvidiortowyArmorItem.Leggings());
	public static final RegistryObject<Item> NVIDIORTOWY_ARMOR_BOOTS = REGISTRY.register("nvidiortowy_armor_boots",
			() -> new NvidiortowyArmorItem.Boots());
	public static final RegistryObject<Item> WENTYLATOR = REGISTRY.register("wentylator", () -> new WentylatorItem());
	public static final RegistryObject<Item> KABELEK = REGISTRY.register("kabelek", () -> new KabelekItem());
	public static final RegistryObject<Item> PROCESOR = REGISTRY.register("procesor", () -> new ProcesorItem());
	public static final RegistryObject<Item> PLASTIK = REGISTRY.register("plastik", () -> new PlastikItem());
	public static final RegistryObject<Item> PLYTKADRUKOWANA = REGISTRY.register("plytkadrukowana", () -> new PlytkadrukowanaItem());
	public static final RegistryObject<Item> KFAS = REGISTRY.register("kfas", () -> new KfasItem());
	public static final RegistryObject<Item> OBUDOWA = REGISTRY.register("obudowa", () -> new ObudowaItem());
	public static final RegistryObject<Item> PLYTAGLOWNA = REGISTRY.register("plytaglowna", () -> new PlytaglownaItem());
	public static final RegistryObject<Item> ZASILAC = REGISTRY.register("zasilac", () -> new ZasilacItem());
	public static final RegistryObject<Item> KOMPUTER = block(VivoCraftModBlocks.KOMPUTER, VivoCraftModTabs.TAB_VIVOCRAFT);

	private static RegistryObject<Item> block(RegistryObject<Block> block, CreativeModeTab tab) {
		return REGISTRY.register(block.getId().getPath(), () -> new BlockItem(block.get(), new Item.Properties().tab(tab)));
	}
}
